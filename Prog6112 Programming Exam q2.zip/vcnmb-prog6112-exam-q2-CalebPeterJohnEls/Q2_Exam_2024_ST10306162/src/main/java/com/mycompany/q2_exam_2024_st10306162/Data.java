/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.q2_exam_2024_st10306162;

/**
 *
 * @author lab_services_student
 */
public class Data {
    //Attributes
    public String Movie ;
     public  String numberOfTickets ;
      public String ticketPrice ;
}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
