/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.q2_exam_2024_st10306162;

/**
 *
 * @author lab_services_student
 */
public class MovieTickets implements IMovieTickets{
  
public double CalculateTotalTicketPrice(String numberOfTickets, String ticketPrice) {
    try {
        // Parse from String to double//(Farrel. 2018)
        double dbCost = Double.parseDouble(ticketPrice);
       
        double dbRate = Double.parseDouble(numberOfTickets);
        
        double preVATPrice=  dbCost * dbRate;
        //Calculate price without VAT
        double totalPrice =preVATPrice+(preVATPrice*0.15);
        // Calculate the total price with VAT//(Farrel. 2018)
        return totalPrice;
    } 
    catch (Exception e) {
        // In case of parsing errors, return 0 as a default value//(Farrel. 2018)
        return 0;
    }
}


public boolean ValidateData(Data dataToValidate) {
    // Initialize a boolean variable to track validation status//(Farrel. 2018)
    Boolean bValidateData = true;
    
    // Check if the Movie Name is empty//(Farrel. 2018)
    if (dataToValidate.Movie.length() <= 0) {
        bValidateData = false;
    }
    
    
    try {
        // Parse and check if the ticket price is over 0//(Farrel. 2018)
        double dblCost = Double.parseDouble(dataToValidate.ticketPrice);
        if (dblCost <= 0) {
            bValidateData = false;
        }

        // Parse and check if the number of tickets over 0//(Farrel. 2018)
        double dblRate = Double.parseDouble(dataToValidate.numberOfTickets);
        if (dblRate <= 0) {
            bValidateData = false;
        }
    } 
    catch (Exception e) {
        // If parsing fails, mark validation as false//(Farrel. 2018)
        bValidateData = false;
    }

    // Return the final validation status//(Farrel. 2018)
    return bValidateData;
}
 
}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
