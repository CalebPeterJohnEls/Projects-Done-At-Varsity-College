/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.q2_exam_2024_st10306162.Data;
import com.mycompany.q2_exam_2024_st10306162.MovieTickets;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class Q2_UnitTest {
    //Test the total price calculation//(Farrel. 2018)
    @Test
   public void CalculateTotalTicketPrice_CalculatedSuccessfuly()
   {
        MovieTickets movieTickets = new MovieTickets();
        double Actual = movieTickets.CalculateTotalTicketPrice("100", "3");
         double Expected = 342.0;
         Assertions.assertEquals(Expected, Actual);
   }
   //Test if the data is valid//(Farrel. 2018)
   @Test
   public void Validation_Tests()
   {
       Data d = new Data();
        d.Movie="Napoleon";
        d.numberOfTickets="3";
        d.ticketPrice="100";
       
         MovieTickets movieTickets = new MovieTickets();
        Boolean Actual = movieTickets.ValidateData(d);
         Boolean Expected = true;
        Assertions.assertTrue(Actual);
   }
    
}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
