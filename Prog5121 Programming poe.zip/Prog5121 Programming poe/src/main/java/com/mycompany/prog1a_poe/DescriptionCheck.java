/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog1a_poe;

/**
 *
 * @author lab_services_student
 */
public class DescriptionCheck {
      //This method to check if task description is correct
     public static boolean checkTaskDescription(String taskDescription) {
         return taskDescription.length() > 1 && taskDescription.length() < 50;//The task description must be between 1 and 50 characters.
    }
}
//(Farrel. 2018)
/*REFERENCE LIST:
·         BeginnersBook. 2022. Java String charAt() Method example [Online]. Available at: https://beginnersbook.com/2013/12/java-string-charat-method-example/#:~:text=The%20Java%20String%20charAt(int,string%20represented%20by%20instance%20s. [Accessed 2 May 2024]
·         Code Knowledge. 2024. For loop in Java: counting loop that repeats the code a specific number of times. [Online]. Available at: https://code-knowledge.com/java-for-loop/#:~:text=In%20Java%2C%20you%20use%20the,a%20predetermined%20number%20of%20times. [Accessed 7 May 2024]
·         DANIWEB. 2013. How can I count the number of user inputs?. [Online]. Available at: https://www.daniweb.com/programming/software-development/threads/349058/how-can-i-count-the-number-of-user-inputs. [Accessed 2 May 2024]
·         Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
·         GeeksforGeeks. 2020. How to validate a Username using Regular Expressions in Java. [Online]. Available at: https://www.geeksforgeeks.org/how-to-validate-a-username-using-regular-expressions-in-java/. [Accessed 1 April 2024]
·         GeeksforGeeks. 2022. How to find the first and last character of a string in Java. [Online]. Available at: https://www.geeksforgeeks.org/how-to-find-the-first-and-last-character-of-a-string-in-java/. [Accessed 7 May 2024]
·         GeeksforGeeks. 2023. Regex Tutorial – How to write Regular Expressions?. [Online]. Available at: https://www.geeksforgeeks.org/write-regular-expressions/. [Accessed 1 April 2024]
·         GeeksforGeeks. 2023. static Keyword in Java. [Online]. Available at: https://www.geeksforgeeks.org/static-keyword-java/. [Accessed 1 April 2024]
·         northCoder. 2022. Passing Java Functions in Variables . [Online]. Available at: https://northcoder.com/post/passing-java-functions-in-variables/[Accessed 7 April 2024]
·         Sanfoundry.2024. Java Program to Illustrate how User Authentication is Done. [Online]. Available at: https://www.sanfoundry.com/java-program-illustrate-how-user-authentication-done/#:~:text=Enter%20username%20and%20password%20as,how%20User%20Authentication%20is%20Done. [Accessed 1 April 2024]
·         Show a drop down list in Java JOptionPane prompt. 2016. YouTube video, added by Brandan Jones. [Online]. Available at: https://www.youtube.com/watch?v=A-R9SrKQmGY [Accessed 2 May 2024].
·         Show a drop down list in Java JOptionPane prompt. 2016. YouTube video, added by Brandan Jones. [Online]. Available at: https://www.youtube.com/watch?v=A-R9SrKQmGY. [Accessed 2 May 2024].
·         Stackflow. 2013. JAVA: Creating a Menu Loop. [Online]. Available at: https://stackoverflow.com/questions/20681616/java-creating-a-menu-loop. [Accessed  1 May 2024]
·         Stackflow. 2014. Sum of previous two numbers entered [Online]. Available at: https://stackoverflow.com/questions/26956242/sum-of-previous-two-numbers-entered. [Accessed  2 May 2024]
·         Stackflow. 2017. java - Show JOptionPane (with dropdown menu) on the top of other windows [Online]. Available at: https://stackoverflow.com/questions/43658679/show-joptionpane-with-dropdown-menu-on-the-top-of-other-windows. [Accessed  2 May 2024]
·         Stackflow. 2022. Can I store a method in a variable in Java 8?. [Online]. Available at: https://stackoverflow.com/questions/29219984/can-i-store-a-method-in-a-variable-in-java-8 [Accessed 7 April 2024]
·         Stackflow. 2022. Valid Username without Regex. [Online]. Available at: https://stackoverflow.com/questions/70642136/valid-username-without-regex#:~:text=If%20the%20username%20consists%20of,digits%20%5B0-9%5D. [Accessed 1 April 2024]
·         Stackflow. 2023. Java: break statement in "if else". [Online]. Available at: https://stackoverflow.com/questions/20670824/java-break-statement-in-if-else. [Accessed 1 April 2024]
·         Stackflow. 2024. ArrayList input java [Online]. Available at: https://stackoverflow.com/questions/12056220/arraylist-input-java. [Accessed  7 May 2024]
·         W3Schools. 2024. Java String toUpperCase() Method. [Online]. Available at: https://www.w3schools.com/java/ref_string_touppercase.asp#:~:text=The%20toUpperCase()%20method%20converts,string%20to%20lower%20case%20letters. [Accessed  6 May 2024]
·         W3Schools. 2024. The JavaScript call() Method. [Online]. Available at: https://www.w3schools.com/js/js_function_call.asp#:~:text=The%20call()%20method%20is,method%20belonging%20to%20another%20object. [Accessed  6 April 2024]
·         Write additional unit tests and update your .yaml file. 2022. YouTube video, added by IIEVC School of Computer Science. [Online]. Available at: https://www.youtube.com/watch?v=DmL4gG9vG0A&list=PL480DYS-b_kfHSYf2yzLgto_mwDr_U-Q6&index=8 [Accessed 10 April 2024].
*/

