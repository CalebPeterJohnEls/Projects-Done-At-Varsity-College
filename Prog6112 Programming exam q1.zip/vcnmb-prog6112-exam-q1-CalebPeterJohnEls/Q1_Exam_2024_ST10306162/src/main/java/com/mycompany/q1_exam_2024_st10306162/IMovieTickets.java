/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.q1_exam_2024_st10306162;

/**
 *
 * @author lab_services_student
 */
public interface IMovieTickets {
    // Method to calculate the total sales for a movie//(Farrel. 2018)
    int TotalMovieSales(int[] movieTicketSales);
    
   
    
    // Method to find the top-performing movie based on total sales//(Farrel. 2018)
    int TopMovie(String[] movies, int[] totalSales);
}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
