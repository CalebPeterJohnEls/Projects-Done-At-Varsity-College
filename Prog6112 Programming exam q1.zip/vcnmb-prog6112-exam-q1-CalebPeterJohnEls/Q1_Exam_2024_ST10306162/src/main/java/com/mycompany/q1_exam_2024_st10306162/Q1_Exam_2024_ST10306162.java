/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.q1_exam_2024_st10306162;

/**
 *
 * @author lab_services_student
 */
public class Q1_Exam_2024_ST10306162 {

    public static void main(String[] args) 
    {
       String[] movies = {"Napoleon", "Oppenheimer"};// Array of movies//(Farrel. 2018)
        int [][] movieTicketSales= {{3000, 1500, 1700},
                         {3500, 1200, 1600}};  // 2D array of ticket sales//(Farrel. 2018)
        //Report header
      System.out.println("---------------------------------------------------\n"
                            + "MOVIE TICKET SALES REPORT - 2024\n"
                            + "---------------------------------------------------");
        System.out.println("\t\t JAN\t\t FEB\t\t MAR");//Coloum headers//(Farrel. 2018)
        
           // Loops through each MOVIE and print the corresponding SALES//(Farrel. 2018)
         for(int x=0; x<movies.length; x++) {
            System.out.print(movies[x]);//Displays movie//(Farrel. 2018)
            System.out.print("\t "+movieTicketSales[x][0]+"\t\t"+movieTicketSales[x][1]+ "\t\t "
                    + ""+movieTicketSales[x][2]+"\n");
            //Displays delivers//(Farrel. 2018)
         }
          System.out.println(" ");
         //Calculate and display total sales for each movie//(Farrel. 2018)
     MovieTickets movieTickets = new MovieTickets();

        int[] totalSales = new int[movies.length];
        for (int x = 0; x <movieTicketSales.length; x++) {
            totalSales[x] = movieTickets.TotalMovieSales(movieTicketSales[x]);
            System.out.println("Total movie ticket sales for " + movies[x] + ": " + totalSales[x]);
        }
        System.out.println(" ");
        // Determine the movie with the most sales//(Farrel. 2018)
        int topMovieIndex = movieTickets.TopMovie(movies,totalSales);
        System.out.println("Top performing movie: " + movies[topMovieIndex]);
    }
}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
