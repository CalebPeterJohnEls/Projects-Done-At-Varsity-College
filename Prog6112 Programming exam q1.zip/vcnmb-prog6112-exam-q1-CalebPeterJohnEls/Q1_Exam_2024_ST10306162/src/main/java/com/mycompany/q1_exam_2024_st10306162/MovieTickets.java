/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.q1_exam_2024_st10306162;

/**
 *
 * @author lab_services_student
 */
public class MovieTickets implements IMovieTickets{
       @Override
public int TotalMovieSales(int[] movieTicketSales) {
    double totalSales = 0;  // Initialize total sales//(Farrel. 2018)
    for (int i = 0; i < movieTicketSales.length; i++) {
        totalSales += movieTicketSales[i];  // Add each movie sale to total//(Farrel. 2018)
    }
    return (int) totalSales;  // Return the total sales//(Farrel. 2018)
}



@Override
public int TopMovie(String[] movies, int[] totalSales) {
    int topMovieIndex = 0;  // Assume the first movie has the highest sales
    int highestSales = totalSales[0];  // Initialize with first movies's sales

    // Iterate through the array to find the top movie
    for (int i = 1; i < totalSales.length; i++) {
        if (totalSales[i] > highestSales) {
            highestSales = totalSales[i];  // Update highest sales//(Farrel. 2018)
            topMovieIndex = i;  // Update the top movie index//(Farrel. 2018)
        }
    }
    return topMovieIndex;  // Return the index of the top movie//(Farrel. 2018)
}

   

}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
