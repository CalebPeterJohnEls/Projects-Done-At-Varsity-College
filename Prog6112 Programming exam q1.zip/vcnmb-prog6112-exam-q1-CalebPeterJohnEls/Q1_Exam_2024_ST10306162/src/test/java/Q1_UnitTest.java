/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.q1_exam_2024_st10306162.MovieTickets;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class Q1_UnitTest {
    
      @Test
    public void CalculateTotalSales_TotalSalesCalculatedSuccessfully() {
       MovieTickets movieTickets = new MovieTickets();
        // movie ticket sales data for a movie
        int[] movieTicketSales = {3000, 1500, 1700};

       //Calculating total sales
        int actual = movieTickets.TotalMovieSales(movieTicketSales);
        int expected = (int) 6200;

        //Verify that the actual total sales match the expected value
        Assertions.assertEquals(expected, actual);
    }

    
    /**
     * Test method to verify that the top movie is identified successfully.
     */
    @Test
    public void TopAgent_TopAgentIdentifiedSuccessfully() {
        MovieTickets movieTickets = new MovieTickets();
        //Total sales for each movie
        int[] totalSales = {6200, 6300};
          String[] movies = {"Napoleon", "Oppenheimer"};

        //Determining the top movie
        int actual =  movieTickets.TopMovie(movies, totalSales);
        int expected = 0; // Index of the top movie

        //Verify that the actual top movie index matches the expected value
        Assertions.assertEquals(expected, actual);
    } 
}
//(Farrel. 2018)





/*REFERENCE LIST:
·    Farrel, J. 2018.Java™ Programming.9th edt. Boston: Cengage.
*/
